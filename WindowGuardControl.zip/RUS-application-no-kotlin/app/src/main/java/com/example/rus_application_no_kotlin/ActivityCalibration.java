package com.example.rus_application_no_kotlin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.sdk.iot.device.DeviceClient;
import com.microsoft.azure.sdk.iot.device.IotHubClientProtocol;
import com.microsoft.azure.sdk.iot.device.IotHubMessageResult;
import com.microsoft.azure.sdk.iot.device.Message;
import com.microsoft.azure.sdk.iot.device.exceptions.IotHubClientException;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.UUID;

public class ActivityCalibration extends AppCompatActivity {

    public TextView CalculationOpened;
    public static TextView CalculationClosed;
    public Button button_back;

    public static float DistanceOpened;
    public static float MessageType;
    public static float DistanceClosed;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calibration);

        CalculationOpened = findViewById(R.id.DistanceOpened);
        CalculationClosed = findViewById(R.id.DistanceClosed);

        CalculationOpened.setText(DistanceOpened + " cm");
        CalculationClosed.setText(DistanceClosed + " cm");

        // DUGME NAZAD
        button_back = findViewById(R.id.button_back);
        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity1();
            }
        });

        // DUGME KALIBRIRAJ ZATVOREN
        Button calibrationClosedButton = findViewById(R.id.calibration_closed);
        calibrationClosedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage(5);
//                changeValueClosed();
            }
        });

        // DUGME KALIBRIRAJ OTVOREN
        Button calibrationOpenedButton = findViewById(R.id.calibration_opened);
        calibrationOpenedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage(4);
//                changeValueOpened();
            }
        });
    }


    public void sendMessage(int value) {
        String iotHubConnectionString = "HostName=HUB-RUS-jbegovic21.azure-devices.net;DeviceId=Androids;SharedAccessKey=ApQkG6BAwHwEcPRXIcVy0BceknIuS2Ys6AIoTIG2F7U=";
        DeviceClient deviceClient = new DeviceClient(iotHubConnectionString, IotHubClientProtocol.MQTT);

        try {
            deviceClient.open(true);
            Log.d("IoTHub", "Successfully connected");

            // Set up message callback
            MessageCallbackMqtt callback = new MessageCallbackMqtt();
            Counter counter = new Counter(0);
            deviceClient.setMessageCallback(callback, counter);

            // Create JSON message
            JSONObject jsonMessage = new JSONObject();
            jsonMessage.put("messageType", value);
            jsonMessage.put("distanceMeasured", 0);

            // Send JSON message
            Message msg = new Message(jsonMessage.toString());
            msg.setContentType("application/json");
            msg.setMessageId(UUID.randomUUID().toString());
            Log.d("IoTHub", jsonMessage.toString());

            deviceClient.sendEvent(msg);
            Log.d("IoTHub", "Successfully sent the message");

            // Wait for response (you may want to handle this asynchronously)
            // For simplicity, we'll just wait for a short duration here.
            Thread.sleep(2000);

            double messageTypeReturn = extractValue(parseJsonToString(new String(msg.getBytes(), Message.DEFAULT_IOTHUB_MESSAGE_CHARSET)));
            double distanceMeasured = extractValue2(parseJsonToString(new String(msg.getBytes(), Message.DEFAULT_IOTHUB_MESSAGE_CHARSET)));
            Log.d("ISPIS ZA CALLBACK", messageTypeReturn + " " + distanceMeasured);

            // Handle the received message
            // You can update UI or perform other actions based on the received message.

            counter.increment();

            if (messageTypeReturn == 3) {
                changeValueClosed(distanceMeasured);
            }
            else if (messageTypeReturn == 2) {
                changeValueOpened(distanceMeasured);
            }

        } catch (IotHubClientException | JSONException | InterruptedException e) {
            Log.e("IoTHub", "Error: " + e.getMessage());
        } finally {
            deviceClient.close();
        }

    }

    class MessageCallbackMqtt implements com.microsoft.azure.sdk.iot.device.MessageCallback
    {
        public IotHubMessageResult onCloudToDeviceMessageReceived(Message msg, Object context)
        {
            Counter counter = (Counter) context;
            double messageTypeReturn = extractValue(parseJsonToString(new String(msg.getBytes(), Message.DEFAULT_IOTHUB_MESSAGE_CHARSET)));
            double distanceMeasured = extractValue2(parseJsonToString(new String(msg.getBytes(), Message.DEFAULT_IOTHUB_MESSAGE_CHARSET)));
            Log.d("ISPIS ZA CALLBACK", messageTypeReturn + " " + distanceMeasured);

            MessageType = (float) messageTypeReturn;

            if (messageTypeReturn == 3) {
                changeValueClosed(distanceMeasured);
            }
            else if (messageTypeReturn == 2) {
                changeValueOpened(distanceMeasured);
            }
            counter.increment();

            return IotHubMessageResult.COMPLETE;
        }
    }

    static class Counter
    {
        int num;

        Counter(int num)
        {
            this.num = num;
        }

        int get()
        {
            return this.num;
        }

        void increment()
        {
            this.num++;
        }

        @Override
        public String toString()
        {
            return Integer.toString(this.num);
        }
    }
    private static String parseJsonToString(String jsonString) {
        try {
            // Create ObjectMapper instance
            ObjectMapper objectMapper = new ObjectMapper();

            // Parse JSON string to JsonNode
            JsonNode jsonNode = objectMapper.readTree(jsonString);

            // Convert JsonNode to String
            return jsonNode.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static double extractValue(String jsonString) {
        try {
            // Create ObjectMapper instance
            ObjectMapper objectMapper = new ObjectMapper();

            // Parse JSON string to JsonNode
            JsonNode jsonNode = objectMapper.readTree(jsonString);

            // Extract value from JsonNode
            double messageType = jsonNode.get("messageType").asDouble();
            // Return the extracted value
            return messageType;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    private static double extractValue2(String jsonString) {
        try {
            // Create ObjectMapper instance
            ObjectMapper objectMapper = new ObjectMapper();

            // Parse JSON string to JsonNode
            JsonNode jsonNode = objectMapper.readTree(jsonString);

            // Extract value from JsonNode
            double messageType = jsonNode.get("distanceMeasured").asDouble();
            // Return the extracted value
            return messageType;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    public void openActivity1(){
        Intent intent = new Intent(this, MainActivity .class);
        startActivity(intent);
    }

    // Update the changeValueClosed() method as follows:
    public void changeValueClosed(double DistanceClosed) {
        runOnUiThread(new Runnable() {
            double roundedValueDistanceClosed = Math.ceil(DistanceClosed * 100) / 100;
            @Override
            public void run() {
                CalculationClosed.setText(roundedValueDistanceClosed + " cm");
            }
        });
    }

    // Update the changeValueOpened() method as follows:
    public void changeValueOpened(double DistanceOpened) {
        runOnUiThread(new Runnable() {
            double roundedValueDistanceOpened = Math.ceil(DistanceOpened * 100) / 100;
            @Override
            public void run() {
                CalculationOpened.setText(roundedValueDistanceOpened + " cm");
            }
        });
    }

}