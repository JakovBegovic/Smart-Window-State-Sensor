package com.example.rus_application_no_kotlin;

public class CountMember {
    int id, count;
}
