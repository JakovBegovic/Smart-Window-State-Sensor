package com.example.rus_application_no_kotlin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.microsoft.azure.sdk.iot.device.DeviceClient;
import com.microsoft.azure.sdk.iot.device.IotHubClientProtocol;
import com.microsoft.azure.sdk.iot.device.IotHubMessageResult;
import com.microsoft.azure.sdk.iot.device.Message;
import com.microsoft.azure.sdk.iot.device.exceptions.IotHubClientException;

import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Array;
import java.util.ArrayList;
import java.util.UUID;

public class Statistics extends AppCompatActivity {

    public Button button_back;
    public static ArrayList<Integer> CountGlobal;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.statistics);

        sendMessage(7);

        button_back = findViewById(R.id.button_back);
        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainActivity();
            }
        });
    }

    private void openMainActivity() {
        Intent intent = new Intent(this, MainActivity .class);
        startActivity(intent);
    }

    class MessageCallbackMqtt implements com.microsoft.azure.sdk.iot.device.MessageCallback
    {
        public IotHubMessageResult onCloudToDeviceMessageReceived(Message msg, Object context)
        {
            Counter counter = (Counter) context;
            Log.i("Poruka", new String(msg.getBytes(), Message.DEFAULT_IOTHUB_MESSAGE_CHARSET));
            ArrayList<Integer> CountArray = extractValue(parseJsonToString(new String(msg.getBytes(), Message.DEFAULT_IOTHUB_MESSAGE_CHARSET)));
            CountGlobal = CountArray;

            Log.i("CountCheck", "CountStringGlobal je " +  CountGlobal.get(1));
            MakeGraph();
            counter.increment();

            return IotHubMessageResult.COMPLETE;
        }
    }

    public void MakeGraph() {
        MyDBHelper dbHelper = new MyDBHelper(this);
        ArrayList<Entry> dataPoints = new ArrayList<>();

        for (int i = 0; i < 24; i++) {
            dbHelper.UpdateById(i, CountGlobal.get(i));
        }

        for (int i = 0; i < 24; i++) {
            dataPoints.add(new Entry(i, dbHelper.SelectById(i)));
        }

        LineDataSet lineDataSet = new LineDataSet(dataPoints, "Number of Sent Messages");
        lineDataSet.setColor(Color.rgb(0, 186, 255));
        lineDataSet.setValueTextColor(Color.BLUE);

        LineData lineData = new LineData(lineDataSet);
        lineData.setDrawValues(true);

        LineChart chart = (LineChart)findViewById(R.id.lineChartOne);
        Legend legend = chart.getLegend();
        legend.setTextSize(14);
        chart.setData(lineData);

        Description description = new Description();

        description.setText("Time of day (h)");
        description.setTextSize(14);
        chart.setDescription(description);

        chart.getData().notifyDataChanged();
        chart.invalidate();
    }

    public void sendMessage(int value) {
        String iotHubConnectionString = "HostName=HUB-RUS-jbegovic21.azure-devices.net;DeviceId=Androids;SharedAccessKey=ApQkG6BAwHwEcPRXIcVy0BceknIuS2Ys6AIoTIG2F7U=";
        DeviceClient deviceClient = new DeviceClient(iotHubConnectionString, IotHubClientProtocol.MQTT);

        try {
            deviceClient.open(true);
            Log.d("IoTHub", "Successfully connected");

            // Set up message callback
            MessageCallbackMqtt callback = new MessageCallbackMqtt();
            Counter counter = new Counter(0);
            deviceClient.setMessageCallback(callback, counter);

            // Create JSON message
            JSONObject jsonMessage = new JSONObject();
            jsonMessage.put("messageType", value);
            jsonMessage.put("distanceMeasured", 0);

            // Send JSON message
            Message msg = new Message(jsonMessage.toString());
            msg.setContentType("application/json");
            msg.setMessageId(UUID.randomUUID().toString());
            Log.d("IoTHub", jsonMessage.toString());

            deviceClient.sendEvent(msg);
            Log.d("IoTHub", "Successfully sent the message");
            // Wait for response (you may want to handle this asynchronously)
            // For simplicity, we'll just wait for a short duration here.
            // izbrisano
            Thread.sleep(2000);
            // Handle the received message
            // You can update UI or perform other actions based on the received message.
            counter.increment();

        } catch (IotHubClientException | JSONException | InterruptedException e) {
            Log.e("IoTHub", "Error: " + e.getMessage());
        } finally {
            deviceClient.close();
        }
    }

    static class Counter
    {
        int num;

        Counter(int num)
        {
            this.num = num;
        }

        int get()
        {
            return this.num;
        }

        void increment()
        {
            this.num++;
        }

        @Override
        public String toString()
        {
            return Integer.toString(this.num);
        }
    }
    private static String parseJsonToString(String jsonString) {
        try {
            // Create ObjectMapper instance
            ObjectMapper objectMapper = new ObjectMapper();

            // Parse JSON string to JsonNode
            JsonNode jsonNode = objectMapper.readTree(jsonString);

            // Convert JsonNode to String
            Log.i("jsonNode", "Odgovor:"+jsonNode.toString());
            return jsonNode.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    private static ArrayList<Integer> extractValue(String jsonString) {
        try {
            // Create ObjectMapper instance
            ObjectMapper objectMapper = new ObjectMapper();

            // Parse JSON string to JsonNode
            JsonNode jsonNode = objectMapper.readTree(jsonString);
            JsonNode jsonArray = jsonNode.get("numOfNotificationsByHour");

            ArrayList<Integer> messageType = new ArrayList<>();
            // Extract value from JsonNode
            for (int i=0;i<jsonArray.size();i++) {
                int Value = jsonArray.get(i).asInt();
                Log.i("Vrijednost", i + " je " + Value);
                messageType.add(Value);
            }
            // Return the extracted value
            Log.i("Message Type Prijevod", "Poruka: " + messageType);
            return messageType;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}