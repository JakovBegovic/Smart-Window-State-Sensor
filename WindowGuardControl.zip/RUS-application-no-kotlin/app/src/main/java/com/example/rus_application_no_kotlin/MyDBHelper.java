package com.example.rus_application_no_kotlin;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class MyDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Statistika";
    private static final int DATABASE_VERSION = 4;
    private static final String TABLE_NAME = "Statistika";

    private static final String KEY_ID = "ID";
    private static final String KEY_COUNT = "Count";
    public MyDBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE "+TABLE_NAME+"("+KEY_ID+" INTEGER PRIMARY KEY, "
        + KEY_COUNT + " INTEGER)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);

        onCreate(db);
    }

    public void SetupDatabase() {
        SQLiteDatabase database = this.getWritableDatabase();

            for (int i=0;i<24;i++) {
                Cursor cursor = database.query(TABLE_NAME, null, KEY_ID + " = " + i, null, null, null, null);
                boolean exists = cursor.moveToNext();
                if (!exists) {
                    ContentValues values = new ContentValues();
                    values.put(KEY_ID, i);
                    values.put(KEY_COUNT, 0);
                    database.insert(TABLE_NAME, null, values);
                }
            }
        database.close();
    }

    public int SelectById(int id) {
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.query(TABLE_NAME, null, KEY_ID + " = " + id, null, null, null, null);
        int Count = 0;
        if (cursor.moveToFirst()) {
            Count = cursor.getInt(1);
        }

        cursor.close();
        database.close();
        return Count;
    }

    public int UpdateById(int id, int count) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_COUNT, count);

        int rowsUpdated = database.update(TABLE_NAME, values, "id = " + id, null);
        database.close();
        return rowsUpdated;
    }
}
