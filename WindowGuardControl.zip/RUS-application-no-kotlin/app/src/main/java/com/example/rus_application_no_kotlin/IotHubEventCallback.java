package com.example.rus_application_no_kotlin;

import android.util.Log;

import com.microsoft.azure.sdk.iot.device.IotHubStatusCode;
import com.microsoft.azure.sdk.iot.device.Message;
import com.microsoft.azure.sdk.iot.device.MessageSentCallback;
import com.microsoft.azure.sdk.iot.device.MessagesSentCallback;
import com.microsoft.azure.sdk.iot.device.exceptions.IotHubClientException;

import java.util.List;

public class IotHubEventCallback implements MessageSentCallback{

    private final String TAG = "IoTHub";
    public void onMessageSent(Message sentMessage, IotHubClientException e, Object context)
    {
        Log.d(TAG, sentMessage.getMessageId());

    }

}
